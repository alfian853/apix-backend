package io.swagger.model;

import java.util.Objects;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonCreator;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import org.springframework.validation.annotation.Validated;
import javax.validation.Valid;
import javax.validation.constraints.*;

/**
 * InlineResponse405
 */
@Validated
@javax.annotation.Generated(value = "io.swagger.codegen.languages.SpringCodegen", date = "2019-06-21T22:35:43.697+07:00")

public class InlineResponse405   {
  @JsonProperty("sat")
  private String sat = null;

  public InlineResponse405 sat(String sat) {
    this.sat = sat;
    return this;
  }

  /**
   * Get sat
   * @return sat
  **/
  @ApiModelProperty(value = "")


  public String getSat() {
    return sat;
  }

  public void setSat(String sat) {
    this.sat = sat;
  }


  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    InlineResponse405 inlineResponse405 = (InlineResponse405) o;
    return Objects.equals(this.sat, inlineResponse405.sat);
  }

  @Override
  public int hashCode() {
    return Objects.hash(sat);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class InlineResponse405 {\n");
    
    sb.append("    sat: ").append(toIndentedString(sat)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}

