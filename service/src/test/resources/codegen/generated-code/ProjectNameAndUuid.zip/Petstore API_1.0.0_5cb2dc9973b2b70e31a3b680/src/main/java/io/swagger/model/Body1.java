package io.swagger.model;

import java.util.Objects;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonCreator;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import io.swagger.model.PetpetIdObjectlv2;
import org.springframework.validation.annotation.Validated;
import javax.validation.Valid;
import javax.validation.constraints.*;

/**
 * Body1
 */
@Validated
@javax.annotation.Generated(value = "io.swagger.codegen.languages.SpringCodegen", date = "2019-06-21T22:35:43.697+07:00")

public class Body1   {
  @JsonProperty("string1")
  private String string1 = null;

  @JsonProperty("objectlv2")
  private PetpetIdObjectlv2 objectlv2 = null;

  public Body1 string1(String string1) {
    this.string1 = string1;
    return this;
  }

  /**
   * Get string1
   * @return string1
  **/
  @ApiModelProperty(value = "")


  public String getString1() {
    return string1;
  }

  public void setString1(String string1) {
    this.string1 = string1;
  }

  public Body1 objectlv2(PetpetIdObjectlv2 objectlv2) {
    this.objectlv2 = objectlv2;
    return this;
  }

  /**
   * Get objectlv2
   * @return objectlv2
  **/
  @ApiModelProperty(value = "")

  @Valid

  public PetpetIdObjectlv2 getObjectlv2() {
    return objectlv2;
  }

  public void setObjectlv2(PetpetIdObjectlv2 objectlv2) {
    this.objectlv2 = objectlv2;
  }


  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    Body1 body1 = (Body1) o;
    return Objects.equals(this.string1, body1.string1) &&
        Objects.equals(this.objectlv2, body1.objectlv2);
  }

  @Override
  public int hashCode() {
    return Objects.hash(string1, objectlv2);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class Body1 {\n");
    
    sb.append("    string1: ").append(toIndentedString(string1)).append("\n");
    sb.append("    objectlv2: ").append(toIndentedString(objectlv2)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}

