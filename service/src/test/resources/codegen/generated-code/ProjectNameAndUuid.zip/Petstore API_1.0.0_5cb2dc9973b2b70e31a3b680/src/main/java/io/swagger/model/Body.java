package io.swagger.model;

import java.util.Objects;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonValue;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import java.util.ArrayList;
import java.util.List;
import org.springframework.validation.annotation.Validated;
import javax.validation.Valid;
import javax.validation.constraints.*;

/**
 * testt
 */
@ApiModel(description = "testt")
@Validated
@javax.annotation.Generated(value = "io.swagger.codegen.languages.SpringCodegen", date = "2019-06-21T22:35:43.697+07:00")

public class Body   {
  /**
   * qnumber desc
   */
  public enum QnumberEnum {
    NUMBER_1_DOT_0(1.0),
    
    NUMBER_2_DOT_0(2.0),
    
    NUMBER_3_DOT_0(3.0);

    private Double value;

    QnumberEnum(Double value) {
      this.value = value;
    }

    @Override
    @JsonValue
    public String toString() {
      return String.valueOf(value);
    }

    @JsonCreator
    public static QnumberEnum fromValue(String text) {
      for (QnumberEnum b : QnumberEnum.values()) {
        if (String.valueOf(b.value).equals(text)) {
          return b;
        }
      }
      return null;
    }
  }

  @JsonProperty("qnumber")
  private QnumberEnum qnumber = 22.0d;

  /**
   * qstring descs
   */
  public enum QstringEnum {
    STRING1("string1"),
    
    STRING2("string2"),
    
    STRING3("string3");

    private String value;

    QstringEnum(String value) {
      this.value = value;
    }

    @Override
    @JsonValue
    public String toString() {
      return String.valueOf(value);
    }

    @JsonCreator
    public static QstringEnum fromValue(String text) {
      for (QstringEnum b : QstringEnum.values()) {
        if (String.valueOf(b.value).equals(text)) {
          return b;
        }
      }
      return null;
    }
  }

  @JsonProperty("qstring")
  private QstringEnum qstring = eq;

  @JsonProperty("qinteger")
  private Integer qinteger = null;

  @JsonProperty("qboolean")
  private Boolean qboolean = true;

  @JsonProperty("qarray")
  @Valid
  private List<List<List<QarrayEnum>>> qarray = null;

  public Body qnumber(QnumberEnum qnumber) {
    this.qnumber = qnumber;
    return this;
  }

  /**
   * qnumber desc
   * minimum: 2
   * maximum: 3
   * @return qnumber
  **/
  @ApiModelProperty(example = "22.0", value = "qnumber desc")

@DecimalMin("2") @DecimalMax("3") 
  public QnumberEnum getQnumber() {
    return qnumber;
  }

  public void setQnumber(QnumberEnum qnumber) {
    this.qnumber = qnumber;
  }

  public Body qstring(QstringEnum qstring) {
    this.qstring = qstring;
    return this;
  }

  /**
   * qstring descs
   * @return qstring
  **/
  @ApiModelProperty(example = "example1", value = "qstring descs")

@Pattern(regexp="qweasd") @Size(max=3) 
  public QstringEnum getQstring() {
    return qstring;
  }

  public void setQstring(QstringEnum qstring) {
    this.qstring = qstring;
  }

  public Body qinteger(Integer qinteger) {
    this.qinteger = qinteger;
    return this;
  }

  /**
   * Get qinteger
   * @return qinteger
  **/
  @ApiModelProperty(value = "")


  public Integer getQinteger() {
    return qinteger;
  }

  public void setQinteger(Integer qinteger) {
    this.qinteger = qinteger;
  }

  public Body qboolean(Boolean qboolean) {
    this.qboolean = qboolean;
    return this;
  }

  /**
   * Get qboolean
   * @return qboolean
  **/
  @ApiModelProperty(example = "true", value = "")


  public Boolean isQboolean() {
    return qboolean;
  }

  public void setQboolean(Boolean qboolean) {
    this.qboolean = qboolean;
  }

  public Body qarray(List<List<List<QarrayEnum>>> qarray) {
    this.qarray = qarray;
    return this;
  }

  public Body addQarrayItem(List<List<QarrayEnum>> qarrayItem) {
    if (this.qarray == null) {
      this.qarray = new ArrayList<List<List<QarrayEnum>>>();
    }
    this.qarray.add(qarrayItem);
    return this;
  }

  /**
   * desc1
   * @return qarray
  **/
  @ApiModelProperty(example = "\"1\"", value = "desc1")

@Size(min=1,max=3) 
  public List<List<List<QarrayEnum>>> getQarray() {
    return qarray;
  }

  public void setQarray(List<List<List<QarrayEnum>>> qarray) {
    this.qarray = qarray;
  }


  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    Body body = (Body) o;
    return Objects.equals(this.qnumber, body.qnumber) &&
        Objects.equals(this.qstring, body.qstring) &&
        Objects.equals(this.qinteger, body.qinteger) &&
        Objects.equals(this.qboolean, body.qboolean) &&
        Objects.equals(this.qarray, body.qarray);
  }

  @Override
  public int hashCode() {
    return Objects.hash(qnumber, qstring, qinteger, qboolean, qarray);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class Body {\n");
    
    sb.append("    qnumber: ").append(toIndentedString(qnumber)).append("\n");
    sb.append("    qstring: ").append(toIndentedString(qstring)).append("\n");
    sb.append("    qinteger: ").append(toIndentedString(qinteger)).append("\n");
    sb.append("    qboolean: ").append(toIndentedString(qboolean)).append("\n");
    sb.append("    qarray: ").append(toIndentedString(qarray)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}

